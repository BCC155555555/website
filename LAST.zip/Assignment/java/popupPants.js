document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("popupButton4").addEventListener("click", function() {
        alert("Sorry, this product is out of stock.");
        
        
   
        
    });
});
