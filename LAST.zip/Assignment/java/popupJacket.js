document.addEventListener("DOMContentLoaded", function() {
    // Add event listener to the element with id "popupButton6"
    document.getElementById("popupButton6").addEventListener("click", function() {
        // When the element with id "popupButton6" is clicked, show an alert message
        alert("Sorry, this product is out of stock.");
    });
});